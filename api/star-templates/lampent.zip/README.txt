Mélancolux — kit de création Star
Source : Cobblemon 1.8.0+1.21.1, forme de base.

1. Ouvre lampent.geo.json dans Blockbench (Bedrock Model).
2. Importe lampent.png comme texture. Recolore-la pour créer ta variante Star.
3. Garde les noms ET parents des os pour conserver les animations natives.
4. Facultatif : peins uniquement les détails lumineux dans lampent_glow.png, transparent au départ.
5. Exporte le modèle .geo.json et les PNG, mêmes dimensions UV.
6. Dans Admin > Pokémon Star, sélectionne lampent, importe, enregistre puis publie.

Les fichiers reference sont informatifs : ne pas les importer comme modèle. Les animations natives restent dans Cobblemon. Ce kit contient la version normale, pas une variante Star publiée.
Assets originaux : équipe Cobblemon, licence jointe. https://gitlab.com/cable-mc/cobblemon
