Quartermac - kit Star addon
Source: Complete Cobblemon Collection - Myths and Legends compat 2.1.0
Licence: LicenseRef-All-Rights-Reserved (jointe). Autorisation de modification/distribution confirmee par l'administrateur.

Ouvrir passimian.geo.json dans Blockbench et importer passimian.png.
Garder les noms et parents des os. Le PNG _glow contient un calque transparent facultatif.
Importer ces trois fichiers dans Admin > Pokemon Star, enregistrer, puis publier.
Ne pas importer les fichiers reference/runtime comme modele. Ils conservent le poser, les animations et les calques de la meme source.
Les animations sont isolees par le site lors de la publication.
Ce kit ne cree pas de Star tant que tu n'as pas publie une variante.
